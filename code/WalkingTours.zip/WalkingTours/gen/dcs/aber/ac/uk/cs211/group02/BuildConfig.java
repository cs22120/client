/** Automatically generated file. DO NOT MODIFY */
package dcs.aber.ac.uk.cs211.group02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}