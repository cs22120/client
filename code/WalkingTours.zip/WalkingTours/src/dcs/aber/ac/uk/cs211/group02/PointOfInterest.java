package dcs.aber.ac.uk.cs211.group02;

public class PointOfInterest {
	
	
	private String name, description;
	private int longitude, lattitude;
	
	public PointOfInterest() {
		
		
		
		
	}
	
	

}
